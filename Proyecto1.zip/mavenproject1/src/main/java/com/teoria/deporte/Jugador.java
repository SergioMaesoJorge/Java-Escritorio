/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.teoria.deporte;

/**
 *
 * @author Tecnicos
 */
public class Jugador {
    int id;
    String nombre;
    float goles;
    boolean titular;

    public Jugador(int id, String nombre, float goles, boolean titular) {
        this.id = id;
        this.nombre = nombre;
        this.goles = goles;
        this.titular = titular;
    }
    
    

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public float getGoles() {
        return goles;
    }

    public boolean isTitular() {
        return titular;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setGoles(float goles) {
        this.goles = goles;
    }

    public void setTitular(boolean titular) {
        this.titular = titular;
    }

    @Override
    public String toString() {
        return "Jugador{" + "id=" + id + ", nombre=" + nombre + ", goles=" + goles + ", titular=" + titular + '}';
    }
    
}
