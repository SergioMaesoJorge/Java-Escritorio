/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.teoria.academia;
import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author Tecnicos
 */
public class Informar {
    public static void main (String[] args){
    Alumno alumno1=new Alumno(100,"Juan López",6,new Date());
    Alumno alumno2=new Alumno(200,"Marta Sánchez",9,new Date());
    Alumno alumno3=new Alumno(300,"Luis López",5,new Date());
    System.out.println(alumno1.toString());
    ArrayList<Alumno> aula9= new ArrayList<>();
    aula9.add(alumno1);
    aula9.add(alumno2);
    aula9.add(alumno3);
}
}
