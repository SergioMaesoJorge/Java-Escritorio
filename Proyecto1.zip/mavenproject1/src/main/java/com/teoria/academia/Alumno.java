/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.teoria.academia;

import java.util.Date;

/**
 *
 * @author Tecnicos
 */
public class Alumno {
    int id;
    String nombre;
    float calificacion;
    Date fecha_alta;

    public Alumno(int id, String nombre, float calificacion, Date fecha_alta) {
        this.id = id;
        this.nombre = nombre;
        this.calificacion = calificacion;
        this.fecha_alta = fecha_alta;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public float getCalificacion() {
        return calificacion;
    }

    public Date getFecha_alta() {
        return fecha_alta;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setCalificacion(float calificacion) {
        this.calificacion = calificacion;
    }

    public void setFecha_alta(Date fecha_alta) {
        this.fecha_alta = fecha_alta;
    }

    @Override
    public String toString() {
        return "Alumno{" + "id=" + id + ", nombre=" + nombre + ", calificacion=" + calificacion + ", fecha_alta=" + fecha_alta + '}';
    }
    
    
}
