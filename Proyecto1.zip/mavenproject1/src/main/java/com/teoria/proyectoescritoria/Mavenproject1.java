/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.teoria.proyectoescritoria;
import com.teoria.deporte.Jugador;
import com.teoria.producto.Producto;
import java.util.Collections;
/**
 *
 * @author Tecnicos
 */
public class Mavenproject1 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        
        String mensaje="Un mensaje de prueba";
        int letras=mensaje.length();
        System.out.println(letras);
        
        double aleatorio=Math.random();
        double numero_generado=aleatorio*100;
        System.out.println("El número aleatorio es: "+numero_generado);
        
        boolean descuento= true;
        if(descuento)
            System.out.println("Descuento aplicado");
        else
            System.out.println("No corresponde descuento");
        
        Jugador jugador=new Jugador(1,"Curtois",20.5f,true);
        jugador.setGoles(32.85f);
        System.out.println(jugador.toString());
       
       Producto producto1=new Producto(1,"Camisa",5,5.95f);
       Producto producto2=new Producto(2,"Pantalones",2,25.65f);
       Producto producto3=new Producto(3,"Sobrero",3,32.50f);
       
    }
}
