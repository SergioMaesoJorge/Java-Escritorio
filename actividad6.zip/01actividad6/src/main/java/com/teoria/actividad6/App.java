/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.teoria.actividad6;

import java.util.Date;
import java.util.Random;
/**
 *
 * @author Tecnicos
 */
public class App {

    public static void main(String[] args) {
        System.out.println(new Date());
        Random randI = new Random();
        int myRandInt = randI.nextInt(100);
        myRandInt = myRandInt+1;
        System.out.println("Random number between 1 and 100: "+myRandInt);
        
        float numero2=myRandInt*9.95f;
        if(numero2%2==0){
            System.out.println("El numero "+numero2+" es par");
        }
        else{
            System.out.println("El numero "+numero2+" es impar");
        }
    }
}
